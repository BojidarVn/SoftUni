package Wild_Farm;

public abstract class Feline extends Mammal  {
    public Feline(String name, String type, Double wight,  String livingRegion) {
        super(name, type, wight,  livingRegion);
    }
}
