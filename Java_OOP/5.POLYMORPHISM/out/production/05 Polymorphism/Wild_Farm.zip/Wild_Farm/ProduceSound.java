package Wild_Farm;

public interface ProduceSound {
    void makeSound();
}
