package Wild_Farm;

public interface Eat {
    void eat(Food food);
}
