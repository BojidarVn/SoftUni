package Food_Shortage_EXERCISE_4;

public interface Birthable {
    String getBirthDate();
}
