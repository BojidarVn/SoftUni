package Food_Shortage_EXERCISE_4;

public interface Identifiable {
    String getId();
}
