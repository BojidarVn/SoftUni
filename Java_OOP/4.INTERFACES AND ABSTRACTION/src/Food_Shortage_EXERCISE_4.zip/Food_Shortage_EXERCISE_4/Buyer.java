package Food_Shortage_EXERCISE_4;

public interface Buyer extends Person{

    void buyFood();
    int getFood();
}
