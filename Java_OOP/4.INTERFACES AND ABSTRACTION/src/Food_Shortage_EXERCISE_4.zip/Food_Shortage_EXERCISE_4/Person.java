package Food_Shortage_EXERCISE_4;

public interface Person {
    String getName();
    int getAge();

}
