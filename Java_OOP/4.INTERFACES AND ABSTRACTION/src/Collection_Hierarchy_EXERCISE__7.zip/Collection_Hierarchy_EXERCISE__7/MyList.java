package Collection_Hierarchy_EXERCISE__7;

public interface MyList extends AddRemovable {
    int getUsed();
}
