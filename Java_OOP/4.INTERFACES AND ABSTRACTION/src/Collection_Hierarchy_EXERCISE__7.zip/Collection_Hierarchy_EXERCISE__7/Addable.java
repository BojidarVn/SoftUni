package Collection_Hierarchy_EXERCISE__7;

public interface Addable {
    int add(String str);
}
