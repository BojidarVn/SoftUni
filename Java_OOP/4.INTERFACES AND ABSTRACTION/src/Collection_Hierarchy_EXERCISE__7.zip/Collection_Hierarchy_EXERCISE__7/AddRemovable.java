package Collection_Hierarchy_EXERCISE__7;

public interface AddRemovable extends Addable {
    String remove();

}
