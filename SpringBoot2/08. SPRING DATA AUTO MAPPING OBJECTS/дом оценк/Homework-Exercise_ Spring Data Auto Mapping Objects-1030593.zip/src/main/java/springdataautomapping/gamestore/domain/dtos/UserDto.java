package springdataautomapping.gamestore.domain.dtos;

import springdataautomapping.gamestore.domain.entities.Game;
import springdataautomapping.gamestore.domain.entities.Role;

import java.util.Set;

public class UserDto {
    private String email;
    private String fullName;
    private Role role;

    public UserDto(){

    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

}
