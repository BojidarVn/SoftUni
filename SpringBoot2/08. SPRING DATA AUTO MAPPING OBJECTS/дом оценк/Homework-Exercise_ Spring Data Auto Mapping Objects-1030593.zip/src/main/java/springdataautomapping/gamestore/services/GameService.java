package springdataautomapping.gamestore.services;

import springdataautomapping.gamestore.domain.dtos.AddGameDto;
import springdataautomapping.gamestore.domain.dtos.UserDto;
import springdataautomapping.gamestore.domain.entities.Game;
import springdataautomapping.gamestore.domain.entities.User;

import java.util.List;
import java.util.Set;

public interface GameService {
    String addGame(AddGameDto addGameDto);

    void setLoggedUser(UserDto userDto);

    String editGame(String item);

    String deleteGame(Long id);

    String getAll();

    String detailsGames(String title);

    String ownGames();

}
