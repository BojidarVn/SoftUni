package springdataautomapping.gamestore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import springdataautomapping.gamestore.domain.dtos.AddGameDto;
import springdataautomapping.gamestore.domain.dtos.UserLoginDto;
import springdataautomapping.gamestore.domain.dtos.UserRegisterDto;
import springdataautomapping.gamestore.services.GameService;
import springdataautomapping.gamestore.services.UserService;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

@Component
@Transactional
public class AppController implements CommandLineRunner {

    private final UserService userService;
    private final GameService gameService;

    @Autowired
    public AppController(UserService userService, GameService gameService) {
        this.userService = userService;
        this.gameService = gameService;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);



        String[] input = scanner.nextLine().split("\\|");

        while (!input[0].equals("End")) {
            if (input[0].equals("RegisterUser")) {
                UserRegisterDto user = new UserRegisterDto(input[1], input[2], input[3], input[4]);

                System.out.println(this.userService.registerUser(user));

            } else if (input[0].equals("LoginUser")) {
                UserLoginDto userLoginDto = new UserLoginDto(input[1], input[2]);



                System.out.println(this.userService.loginUser(userLoginDto));

            } else if(input[0].equals("Logout")) {
                System.out.println(this.userService.logout());

            } else if(input[0].equals("AddGame")){
                AddGameDto addGameDto = new AddGameDto(input[1] , new BigDecimal(input[2]) ,
                        Double.parseDouble(input[3]) , input[4] , input[5] , input[6] ,
                        LocalDate.parse(input[7] , DateTimeFormatter.ofPattern("dd-MM-yyyy")));

                System.out.println(this.gameService.addGame(addGameDto));
            } else if(input[0].equals("DeleteGame")){
                System.out.println(this.gameService.deleteGame(Long.valueOf(input[1])));

            } else if(input[0].equals("EditGame")){

                String line = String.join("|" , input);
                System.out.println(this.gameService.editGame(line));

            } else if(input[0].equals("AllGames")){
                System.out.print(this.gameService.getAll());

            } else if(input[0].equals("DetailGame")){
                String title = input[1];
                System.out.print(this.gameService.detailsGames(title));
            } else if(input[0].equals("OwnedGames")){
                //TODO
            }

            input = scanner.nextLine().split("\\|");
        }
    }
}
