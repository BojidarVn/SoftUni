package springdataautomapping.gamestore.domain.entities;

public enum Role {
    ADMIN , USER
}
