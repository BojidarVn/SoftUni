package springdataautomapping.gamestore.config;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springdataautomapping.gamestore.utils.ValidatorUtil;
import springdataautomapping.gamestore.utils.ValidatorUtilImpl;

import javax.transaction.Transactional;
import javax.validation.Validation;
import javax.validation.Validator;

@Configuration
@Transactional
public class ApplicationBeanConfiguration {

    @Bean
    public ModelMapper modelMapper(){
        return new ModelMapper();
    }

    @Bean
    public Validator validator(){
        return Validation.buildDefaultValidatorFactory().getValidator();
    }

    @Bean
    public ValidatorUtil validatorUtil(){
        return new ValidatorUtilImpl(validator());
    }
}
