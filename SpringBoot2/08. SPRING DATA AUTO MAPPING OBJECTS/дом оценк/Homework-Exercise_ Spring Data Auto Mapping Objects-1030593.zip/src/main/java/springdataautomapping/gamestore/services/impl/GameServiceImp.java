package springdataautomapping.gamestore.services.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import springdataautomapping.gamestore.domain.dtos.*;
import springdataautomapping.gamestore.domain.dtos.view.AllGamesDto;
import springdataautomapping.gamestore.domain.dtos.view.DetailsGameDto;
import springdataautomapping.gamestore.domain.entities.Game;
import springdataautomapping.gamestore.domain.entities.Role;
import springdataautomapping.gamestore.repository.GameRepository;
import springdataautomapping.gamestore.services.GameService;
import springdataautomapping.gamestore.utils.ValidatorUtil;

import javax.validation.ConstraintViolation;
import java.math.BigDecimal;
import java.util.*;

@Service
public class GameServiceImp implements GameService {

    private final ValidatorUtil validatorUtil;
    private final GameRepository gameRepository;
    private final ModelMapper modelMapper;
    private UserDto userDto;

    @Autowired
    public GameServiceImp(ValidatorUtil validatorUtil, GameRepository gameRepository, ModelMapper modelMapper) {
        this.validatorUtil = validatorUtil;
        this.gameRepository = gameRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public void setLoggedUser(UserDto userDto) {
        this.userDto = userDto;
    }

    @Override
    public String editGame(String item) {
        boolean valid = false;
        Set<ConstraintViolation<Game>> violations = new HashSet<>();
        StringBuilder sb = new StringBuilder();


        if (this.userDto == null || this.userDto.getRole().equals(Role.USER)) {
            sb.append("You are not Admin!");

        } else {
            String[] input = item.split("\\|");
            long id = Long.parseLong(input[1]);
            Optional<Game> game = this.gameRepository.findAllById(id);


            if (!game.isPresent()) {
                sb.append("Wrong ID");

            } else {
                for (int i = 2; i < input.length; i++) {
                    String[] token = input[i].split("\\=");

                    if (token[0].equals("title")) {
                        valid = this.validatorUtil.isValid(game.get().getTitle());

                        if (valid) {
                            game.get().setTitle(token[1]);
                            this.gameRepository.saveAndFlush(game.get());
                        }


                    } else if (token[0].equals("price")) {
                        valid = this.validatorUtil.isValid(game.get().getPrice());

                        if (valid) {
                            game.get().setPrice(new BigDecimal(token[1]));
                            this.gameRepository.saveAndFlush(game.get());
                        }


                    } else if (token[0].equals("size")) {
                        valid = this.validatorUtil.isValid(game.get().getSize());

                        if (valid) {
                            game.get().setSize(Double.parseDouble(token[1]));
                            this.gameRepository.saveAndFlush(game.get());
                        }

                    } else if (token[0].equals("trailer")) {
                        valid = this.validatorUtil.isValid(game.get().getTrailer());

                        if (valid) {
                            game.get().setTrailer(token[1]);
                            this.gameRepository.saveAndFlush(game.get());
                        }


                    } else if (token[0].equals("thumbnailURL")) {
                        valid = this.validatorUtil.isValid(game.get().getImageThumbnail());

                        if (valid) {
                            game.get().setImageThumbnail(token[1]);
                            this.gameRepository.saveAndFlush(game.get());
                        }


                    } else if (token[0].equals("description")) {
                        valid = this.validatorUtil.isValid(game.get().getDescription());

                        if (valid) {
                            game.get().setDescription(token[1]);
                            this.gameRepository.saveAndFlush(game.get());
                        }

                    } else if (!valid) {
                        violations = this.validatorUtil.violations(game.get());
                    }
                }
                sb.append(String.format("Edit %s", game.get().getTitle()));
            }
        }
        for (ConstraintViolation<Game> violation : violations) {
            sb.append(violation.getMessage()).append(System.lineSeparator());
        }

        return sb.toString();
    }

    @Override
    public String addGame(AddGameDto addGameDto) {
        StringBuilder sb = new StringBuilder();

        if (this.userDto == null || this.userDto.getRole().equals(Role.USER)) {
            sb.append("You are not Admin!");

        } else if (this.validatorUtil.isValid(addGameDto)) {
            Game game = this.modelMapper.map(addGameDto, Game.class);

            this.gameRepository.saveAndFlush(game);

            sb.append(String.format("Added %s", game.getTitle()));

        } else {
            this.validatorUtil.violations(addGameDto)
                    .forEach(a -> sb.append(a.getMessage()).append(System.lineSeparator()));
        }
        return sb.toString();
    }

    @Override
    public String deleteGame(Long id) {
        StringBuilder sb = new StringBuilder();


        if (this.userDto == null || this.userDto.getRole().equals(Role.USER)) {
            sb.append("You are not Admin!");
        } else {
            Optional<Game> game = this.gameRepository.findAllById(id);

            if (!game.isPresent()) {
                sb.append("Incorrect ID");
            } else {
                this.gameRepository.delete(game.get());
                sb.append(String.format("Deleted %s", game.get().getTitle()));
            }
        }

        return sb.toString();
    }

    @Override
    public String getAll() {
        StringBuilder sb = new StringBuilder();
        List<Game> allGames = this.gameRepository.findAll();
        if (allGames.isEmpty()) {
            sb.append("No have game in DB");
        } else {
            for (Game game : allGames) {

                AllGamesDto allGamesDto = this.modelMapper.map(game, AllGamesDto.class);
                sb.append(String.format("%s %.2f%n", allGamesDto.getTitle(), allGamesDto.getPrice())).append(System.lineSeparator());


            }
        }
        return sb.toString();
    }

    @Override
    public String detailsGames(String title) {
        StringBuilder sb = new StringBuilder();
        Optional<Game> game = this.gameRepository.findAllByTitle(title);

        if (game.isPresent()) {
            DetailsGameDto detailsGameDto = this.modelMapper.map(game.get(), DetailsGameDto.class);
            sb.append(String.format("Title: %s", detailsGameDto.getTitle())).append(System.lineSeparator());
            sb.append(String.format("Price: %.2f", detailsGameDto.getPrice())).append(System.lineSeparator());
            sb.append(String.format("Description: %s", detailsGameDto.getDescription())).append(System.lineSeparator());
            sb.append(String.format("Release date: %s", detailsGameDto.getReleaseDate())).append(System.lineSeparator());


        } else {
            sb.append("Don't have this title.");
        }

        return sb.toString();
    }

    @Override
    public String ownGames() {
        StringBuilder sb = new StringBuilder();
        if (this.userDto == null) {
            sb.append("You are not login");
        } else {


        }
        return null;


    }



}


