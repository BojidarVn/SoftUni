package springdataautomapping.gamestore.services.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import springdataautomapping.gamestore.domain.dtos.UserDto;
import springdataautomapping.gamestore.domain.dtos.UserLoginDto;
import springdataautomapping.gamestore.domain.dtos.UserRegisterDto;
import springdataautomapping.gamestore.domain.entities.Role;
import springdataautomapping.gamestore.domain.entities.User;
import springdataautomapping.gamestore.repository.UserRepository;
import springdataautomapping.gamestore.services.GameService;
import springdataautomapping.gamestore.services.UserService;
import springdataautomapping.gamestore.utils.ValidatorUtil;

import javax.validation.ConstraintViolation;
import java.util.Optional;
import java.util.Set;

@Service
public class UserServiceImpl implements UserService {

    private final GameService gameService;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private UserDto loggedUser;

    @Autowired
    public UserServiceImpl(GameService gameService, ValidatorUtil validatorUtil, ModelMapper modelMapper, UserRepository userRepository) {
        this.gameService = gameService;
        this.validatorUtil = validatorUtil;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
    }

    @Override
    public String registerUser(UserRegisterDto userRegisterDto) {
        StringBuilder sb = new StringBuilder();

        if(!userRegisterDto.getPassword().equals(userRegisterDto.getConfirmPassword())){
            sb.append("Confirm password is incorrect!");

        } else if(this.validatorUtil.isValid(userRegisterDto)){
            User user = this.modelMapper.map(userRegisterDto, User.class);

            if(this.userRepository.count() == 0){
                user.setRole(Role.ADMIN);
            } else {
                user.setRole(Role.USER);
            }

            sb.append(String.format("%s was registered." , userRegisterDto.getFullName()));

            this.userRepository.saveAndFlush(user);

        } else {
            Set<ConstraintViolation<UserRegisterDto>> violations = this.validatorUtil.violations(userRegisterDto);
            for (ConstraintViolation<UserRegisterDto> violation : violations) {
                violation.getMessage();
            }

            this.validatorUtil.violations(userRegisterDto)
                    .forEach(a-> sb.append(String.format("%s%n" , a.getMessage())));
        }


        return sb.toString();

    }

    @Override
    public String loginUser(UserLoginDto userLoginDto) {
        StringBuilder sb = new StringBuilder();
        Optional<User> user = this.userRepository
                .findAllByEmailAndPassword(userLoginDto.getEmail(), userLoginDto.getPassword());

        if(user.isPresent()){
            if(this.loggedUser != null){
                sb.append("User is already logged in.");

            } else {
                this.loggedUser = modelMapper.map(user.get(), UserDto.class);

                sb.append(String.format("Successfully logged in %s" , user.get().getFullName()));

                this.gameService.setLoggedUser(this.loggedUser);

            }

        } else {
            sb.append("Incorrect username / password");
        }
        return sb.toString();
    }

    @Override
    public String logout() {
        if(this.loggedUser == null){
           return "Cannot log out. No user was logged in.";
        } else {
            String message = String.format("User %s successfully logged out.", loggedUser.getFullName());
            this.loggedUser = null;
            return message;
        }
    }
}
