package springdataautomapping.gamestore.domain.dtos.view;

public class OwnGamesDto {
    private String title;

    public OwnGamesDto(){

    }
    public OwnGamesDto(String title){
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
