package com.example.automappingexercise.domain.entities;

public enum  Role {

    ADMIN , USER

}
