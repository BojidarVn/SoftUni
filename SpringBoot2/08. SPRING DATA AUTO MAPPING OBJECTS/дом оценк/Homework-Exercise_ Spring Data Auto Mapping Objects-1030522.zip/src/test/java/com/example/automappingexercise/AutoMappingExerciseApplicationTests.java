package com.example.automappingexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoMappingExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
