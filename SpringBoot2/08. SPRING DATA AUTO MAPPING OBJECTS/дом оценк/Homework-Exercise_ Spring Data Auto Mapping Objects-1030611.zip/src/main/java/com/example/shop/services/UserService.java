package com.example.shop.services;

import com.example.shop.dtos.UserRegisterDto;

public interface UserService {

    String registerUser(UserRegisterDto userRegisterDto);

}
