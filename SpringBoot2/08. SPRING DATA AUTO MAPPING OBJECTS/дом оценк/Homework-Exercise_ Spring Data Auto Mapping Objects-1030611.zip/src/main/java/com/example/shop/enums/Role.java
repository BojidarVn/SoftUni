package com.example.shop.enums;

public enum Role {
    ADMIN, USER
}
