package com.example.shop.services;

import com.example.shop.dtos.UserRegisterDto;
import com.example.shop.entities.User;
import com.example.shop.enums.Role;
import com.example.shop.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;

    public UserServiceImpl(ModelMapper modelMapper, UserRepository userRepository) {
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
    }

    @Override
    public String registerUser(UserRegisterDto userRegisterDto) {

        User user = this.modelMapper.map(userRegisterDto, User.class);

        if (this.userRepository.count() == 0) {
            user.setRole(Role.ADMIN);
        }else {
            user.setRole(Role.USER);
        }
        this.userRepository.saveAndFlush(user);

        return "Created";
    }


}
