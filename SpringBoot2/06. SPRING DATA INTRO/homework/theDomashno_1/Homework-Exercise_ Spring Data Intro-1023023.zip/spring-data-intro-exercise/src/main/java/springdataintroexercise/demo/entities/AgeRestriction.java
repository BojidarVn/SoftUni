package springdataintroexercise.demo.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
