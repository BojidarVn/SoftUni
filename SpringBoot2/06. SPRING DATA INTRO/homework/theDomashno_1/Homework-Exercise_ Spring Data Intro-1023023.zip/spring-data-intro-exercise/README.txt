1. Import project into your IDE
2. Change username and password in APPLICATION.PROPERTIES.