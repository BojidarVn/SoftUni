package com.springintroexercise.springintroexercise.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
