package com.springintroexercise.springintroexercise.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
