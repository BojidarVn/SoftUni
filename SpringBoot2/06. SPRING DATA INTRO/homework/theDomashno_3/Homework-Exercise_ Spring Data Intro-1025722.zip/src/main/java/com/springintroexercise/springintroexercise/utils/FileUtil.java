package com.springintroexercise.springintroexercise.utils;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface FileUtil {

    String[] fileContext(String path) throws IOException;
}
