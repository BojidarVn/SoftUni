package com.springintroexercise.springintroexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringintroExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringintroExerciseApplication.class, args);
    }

}
