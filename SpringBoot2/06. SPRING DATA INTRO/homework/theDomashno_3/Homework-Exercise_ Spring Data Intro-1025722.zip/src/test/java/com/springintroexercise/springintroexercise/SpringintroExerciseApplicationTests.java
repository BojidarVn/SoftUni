package com.springintroexercise.springintroexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringintroExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
