package com.softuni.product_shop.utils;

import javax.swing.text.html.parser.Entity;
import javax.validation.ConstraintViolation;
import java.util.Set;

public interface ValidatorUtil {
    <T> boolean isValid(T entity);
    <T> Set<ConstraintViolation<T>> getViolation(T entity);
}
