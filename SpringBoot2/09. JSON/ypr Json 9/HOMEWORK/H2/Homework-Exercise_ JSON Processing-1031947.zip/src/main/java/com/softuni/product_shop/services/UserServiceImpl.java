package com.softuni.product_shop.services;

import com.softuni.product_shop.models.dto.*;
import com.softuni.product_shop.models.entities.Product;
import com.softuni.product_shop.models.entities.User;
import com.softuni.product_shop.repositories.UserRepository;
import com.softuni.product_shop.utils.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    private UserRepository userRepository;
    private ModelMapper modelMapper;
    private ValidatorUtil validatorUtil;


    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, ValidatorUtil validatorUtil) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.validatorUtil = validatorUtil;
    }


    @Override
    public void seedUsers(UserSeedDto[] userSeedDtos) {
        if (this.userRepository.count() != 0) {
            return;
        }
        Arrays.stream(userSeedDtos)
                .forEach(userSeedDto -> {
                    if(this.validatorUtil.isValid(userSeedDto)) {
                        User user = this.modelMapper.map(userSeedDto, User.class);
                        this.userRepository.saveAndFlush(user);
                    }else {
                        this.validatorUtil.getViolation(userSeedDto)
                                .stream().map(ConstraintViolation::getMessage)
                                .forEach(System.out::println);
                    }
                });

    }

    @Override
    public User getRandomUser() {
        Random random = new Random();
        long randomId = random.nextInt((int) this.userRepository.count()) + 1;
        return this.userRepository.getOne(randomId);
    }

    @Override
    public List<UserSoldProductsDto> getAllUsersBySoldProducts() {
        return this.userRepository.findAllBySoldIsNotNull()
                .stream()
                .map(u -> {
                    UserSoldProductsDto userSoldProducts = this.modelMapper.map(u, UserSoldProductsDto.class);
                    List<Product> soldProducts = new ArrayList<>();
                    for (Product product : u.getSold()) {
                        if (product.getBuyer() != null) {
                            soldProducts.add(product);
                        }
                    }
                    List<ProductSoldDto> productsSoldDtos = new ArrayList<>();
                    soldProducts.forEach(p -> {
                        ProductSoldDto productsSoldDto = this.modelMapper.map(p, ProductSoldDto.class);
                        productsSoldDto.setBuyerFirstName(p.getBuyer().getFirstName());
                        productsSoldDto.setBuyerLastName(p.getBuyer().getLastName());
                        productsSoldDtos.add(productsSoldDto);
                    });
                    userSoldProducts.setSoldProducts(productsSoldDtos);
                    return userSoldProducts;
                })
//                .sorted(Comparator.comparing(UserSoldProductsDto::getFirstName))
//                .sorted(Comparator.comparing(UserSoldProductsDto::getLastName))
                .collect(Collectors.toList());
    }

    @Override
    public UsersAndProductsDto getUserAndProducts() {
        Set<User> usersWithSoldProducts = userRepository.findUsersWithSoldProducts();

        return new UsersAndProductsDto(usersWithSoldProducts.size(),
                usersWithSoldProducts
                        .stream()
                        .map(u -> new UserSoldWithAgeDto(u.getFirstName(), u.getLastName(), u.getAge(),
                                new ProductsDtoCount(
                                        u.getSold().stream().filter(x -> x.getBuyer() != null).count(),
                                        u.getSold().stream()
                                                .filter(x -> x.getBuyer() != null)
                                                .map(p -> new ProductNameAndPriceDto(p.getName(), p.getPrice()))
                                                .collect(Collectors.toList()))))
                        .sorted(Comparator.comparing((UserSoldWithAgeDto x) -> -x.getSoldProducts().getProducts().size())
                                .thenComparing(UserSoldWithAgeDto::getLastName))
                        .collect(Collectors.toList()));
    }
}
