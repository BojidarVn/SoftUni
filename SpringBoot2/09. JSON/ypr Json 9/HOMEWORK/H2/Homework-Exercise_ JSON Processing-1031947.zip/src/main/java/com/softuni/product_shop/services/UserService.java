package com.softuni.product_shop.services;

import com.softuni.product_shop.models.dto.UserSeedDto;
import com.softuni.product_shop.models.dto.UserSoldProductsDto;
import com.softuni.product_shop.models.dto.UsersAndProductsDto;
import com.softuni.product_shop.models.entities.User;

import java.util.List;

public interface UserService {

    void seedUsers(UserSeedDto[] userSeedDtos);
    User getRandomUser();
    List<UserSoldProductsDto> getAllUsersBySoldProducts();

    UsersAndProductsDto getUserAndProducts();
}
