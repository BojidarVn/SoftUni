package com.softuni.product_shop.services;

import com.softuni.product_shop.models.dto.ProductInRangeDto;
import com.softuni.product_shop.models.dto.ProductSeedDto;
import com.softuni.product_shop.models.dto.UserSoldProductsDto;

import java.util.List;

public interface ProductService {
    void seedProducts(ProductSeedDto[] dtos);

    List<ProductInRangeDto> getAllProductsInRange();


}
