package com.softuni.product_shop.controllers;

import com.google.gson.Gson;
import com.softuni.product_shop.constants.GlobalConstant;
import com.softuni.product_shop.models.dto.*;
import com.softuni.product_shop.services.CategoryService;
import com.softuni.product_shop.services.ProductService;
import com.softuni.product_shop.services.UserService;
import com.softuni.product_shop.utils.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

@Component
public class AppController implements CommandLineRunner {
    private final Gson gson;
    private final CategoryService categoryService;
    private final UserService userService;
    private final ProductService productService;
    private final FileUtil fileUtil;
    private final BufferedReader reader;

    @Autowired
    public AppController(Gson gson, CategoryService categoryService,
                         UserService userService, ProductService productService,
                         FileUtil fileUtil, BufferedReader reader) {
        this.gson = gson;
        this.categoryService = categoryService;
        this.userService = userService;
        this.productService = productService;
        this.fileUtil = fileUtil;
        this.reader = reader;
    }

    @Override
    public void run(String... args) throws Exception {
//I didn't have enough time to implement CAR DEALER and better decision for ProductShop,
// because I work and study the same time.
// Please first seed the database and after that start the queries
        //2. Seed the Database
        this.seedCategories();
        this.seedUsers();
        this.seedProducts();

        //3. Query and Export Data
        System.out.println("Enter number of Query:");
        String input = reader.readLine();

        switch (input) {
            case"1":
                //query 1
                this.writeProductsInRange();
                break;
            case"2":
                //query 2
                this.writeUsersSoldProducts();
                break;
            case"3":
                //query 3
                 this.writeCategoriesByProductCount();
                 break;
            case"4":
                //query 4
                this.writeUsersAndProducts();
                break;
        }



    }

    private void writeUsersAndProducts() throws IOException {
        UsersAndProductsDto usersAndProductsDtos = this.userService.getUserAndProducts();
        String userANdProductsToJson = this.gson.toJson(usersAndProductsDtos);
        this.fileUtil.write(userANdProductsToJson, GlobalConstant.USER_AND_PRODUCT_PATH);

    }

    private void writeCategoriesByProductCount() throws IOException {
        List<CategoriesByProductCountDto> categoriesByProductCountDtos =
                this.categoryService.findCategoryWithProductCount();
        String json = this.gson.toJson(categoriesByProductCountDtos);
        this.fileUtil.write(json, GlobalConstant.CATEGORY_PRODUCT_COUNT_PATH);
    }

    private void writeUsersSoldProducts() throws IOException {
        List<UserSoldProductsDto> userSoldProductsDtos = this.userService.getAllUsersBySoldProducts();
        String json = this.gson.toJson(userSoldProductsDtos);
        this.fileUtil.write(json, GlobalConstant.SOlD_PRODUCT_BY_USER);
    }

    private void writeProductsInRange() throws IOException {
        List<ProductInRangeDto> dtos = this.productService.getAllProductsInRange();
        String json = this.gson.toJson(dtos);
        this.fileUtil.write(json, GlobalConstant.PRODUCTS_IN_RANGE);
    }

    private void seedProducts() throws FileNotFoundException {
        ProductSeedDto [] dtos = this.gson
                .fromJson(new FileReader(GlobalConstant.PRODUCTS_FILE_PATH), ProductSeedDto[].class);

        this.productService.seedProducts(dtos);
    }

    private void seedUsers() throws FileNotFoundException {
        UserSeedDto[] userSeedDtos = this.gson.
                fromJson(new FileReader(GlobalConstant.USERS_FILE_PATH), UserSeedDto[].class);
        this.userService.seedUsers(userSeedDtos);
    }
    private void seedCategories() throws FileNotFoundException {
        CategorySeedDto[] categorySeedDtos = this.gson.
                fromJson(new FileReader(GlobalConstant.CATEGORIES_FILE_PATH),
                CategorySeedDto[].class);

        this.categoryService.seedCategories(categorySeedDtos);
    }
}
