package com.softuni.product_shop.constants;

public class GlobalConstant {
    public static final String CATEGORIES_FILE_PATH = "src/main/resources/categories.json";
    public static final String PRODUCTS_FILE_PATH = "src/main/resources/products.json";
    public static final String USERS_FILE_PATH = "src/main/resources/users.json";
    public static final String PRODUCTS_IN_RANGE = "src/main/resources/Output_Ex1";
    public static final String SOlD_PRODUCT_BY_USER = "src/main/resources/Output_ex2";
    public static final String USER_AND_PRODUCT_PATH = "src/main/resources/Output_ex4";
    public static final String CATEGORY_PRODUCT_COUNT_PATH = "src/main/resources/Output_ex3";

}
