package com.softuni.product_shop.services;

import com.softuni.product_shop.models.dto.CategoriesByProductCountDto;
import com.softuni.product_shop.models.dto.CategorySeedDto;
import com.softuni.product_shop.models.entities.Category;

import java.util.List;

public interface CategoryService {
    void seedCategories(CategorySeedDto[] categorySeedDtos);
    List<Category> getRandomCategories();

    List<CategoriesByProductCountDto> findCategoryWithProductCount();
}
