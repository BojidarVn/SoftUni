package com.softuni.product_shop.repositories;

import com.softuni.product_shop.models.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    List<User> findAllBySoldIsNotNull();
    @Query(value = "SELECT u FROM User as u JOIN u.sold as p WHERE p.buyer IS NOT NULL" +
            " ORDER BY u.lastName, u.firstName")
    Set<User> findUsersWithSoldProducts();


}
