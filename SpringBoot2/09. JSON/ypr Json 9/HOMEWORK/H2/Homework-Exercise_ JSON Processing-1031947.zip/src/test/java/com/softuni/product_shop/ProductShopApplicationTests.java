package com.softuni.product_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
