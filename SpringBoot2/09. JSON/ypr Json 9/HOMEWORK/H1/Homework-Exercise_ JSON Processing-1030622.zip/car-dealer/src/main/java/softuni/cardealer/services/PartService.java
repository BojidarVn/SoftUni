package softuni.cardealer.services;

import java.io.IOException;

public interface PartService {

    void seedPartsInDB() throws IOException;
}
