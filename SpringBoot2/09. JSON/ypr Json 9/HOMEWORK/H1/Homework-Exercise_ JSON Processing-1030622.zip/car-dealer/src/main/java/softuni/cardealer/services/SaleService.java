package softuni.cardealer.services;

public interface SaleService {

    void seedSalesInDB();

    String getCustomersWithSales();

    String getAllSalesInfo();
}
