package softuni.productshop.services;

import java.io.IOException;

public interface UserService {

    void seedUsersInDB() throws IOException;
}
