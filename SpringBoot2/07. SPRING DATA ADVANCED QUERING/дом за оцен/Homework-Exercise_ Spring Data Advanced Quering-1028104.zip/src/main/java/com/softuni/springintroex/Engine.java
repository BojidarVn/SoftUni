package com.softuni.springintroex;

import com.softuni.springintroex.services.AuthorService;
import com.softuni.springintroex.services.BookService;
import com.softuni.springintroex.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Scanner;

@Component
public class Engine implements CommandLineRunner {
    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;

    @Autowired
    public Engine(CategoryService categoryService, AuthorService authorService, BookService bookService) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
//        seedData();
        String message = "Please select a number from 1 to 11 for the corresponding exercise\nor type exit to end the program";
        System.out.println(message);
        String command = scanner.nextLine();
        while (!command.equalsIgnoreCase("Exit")) {
            int number;
            try {
                number = Integer.parseInt(command);
                switch (number) {
                    case 1:
                        this.bookService.printAllBooksByAgeRestriction("teEn");
                        break;
                    case 2:
                        this.bookService.findAllByEditionTypeEqualsAndCopiesLessThan("gOLD", 5000);
                        break;
                    case 3:
                        this.bookService.findAllByPriceNotIn(5, 40);
                        break;
                    case 4:
                        System.out.println("Type in release year:");
                        this.bookService.findAllByDifferentReleaseYear(Integer.parseInt(scanner.nextLine()));
                        break;
                    case 5:
                        System.out.println("Type in release date:");
                        this.bookService.findAllByReleaseDateBefore(scanner.nextLine());
                        break;
                    case 6:
                        System.out.println("Type in first name:");
                        this.authorService.findAllByFirstNameEndsWith(scanner.nextLine());
                        break;
                    case 7:
                        System.out.println("Type in string search pattern:");
                        this.bookService.findAllByTitleContains(scanner.nextLine());
                        break;
                    case 8:
                        System.out.println("Type in string pattern to search in authors' last names:");
                        this.bookService.findAllByAuthorLastNameStartsWith(scanner.nextLine());
                        break;
                    case 9:
                        System.out.println("Type in title length:");
                        this.bookService.getNumberOfBooksBasedOnLength(Integer.parseInt(scanner.nextLine()));
                        break;
                    case 10:
                        this.authorService.printAllAuthorsByBooksCopies();
                        break;
                    case 11:
                        System.out.println("Type in book title:");
                        this.bookService.findBookByTitle(scanner.nextLine());
                        break;
                    default:
                        System.out.println("Invalid number");
                        break;
                }
            } catch (NumberFormatException exception){
                System.out.println("Invalid input");
            }

            System.out.println("\n" + message);
            command = scanner.nextLine();
        }

        System.out.println("Thank you! Goodbye!");
    }

    void seedData() throws IOException {
        this.categoryService.seedCategoriesInDB();
        this.authorService.seedAuthorsInDb();
        this.bookService.seedBooksInDb();
    }
}
