package com.softuni.springintroex.domain.entities;

public enum  EditionType {
    NORMAL, PROMO , GOLD;
}
