package com.softuni.springintroex.services;

import com.softuni.springintroex.services.models.BookInfo;

import java.io.IOException;

public interface BookService {
    void seedBooksInDb() throws IOException;

    void printAllBooksByAgeRestriction(String ageRes);

    void findAllByEditionTypeEqualsAndCopiesLessThan(String editionType, int copies);

    void findAllByPriceNotIn(int num1, int num2);

    void findAllByDifferentReleaseYear(int year);

    void findAllByReleaseDateBefore(String dateInfo);

    void findAllByTitleContains(String pattern);

    void findAllByAuthorLastNameStartsWith(String pattern);

    void getNumberOfBooksBasedOnLength(int length);

    void findBookByTitle(String title);

}
