package com.softuni.springintroex.services;

import com.softuni.springintroex.constants.GlobalConstants;
import com.softuni.springintroex.domain.entities.Author;
import com.softuni.springintroex.domain.repositories.AuthorRepository;
import com.softuni.springintroex.utils.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import static com.softuni.springintroex.constants.GlobalConstants.*;

@Service
public class AuthorServiceImpl implements AuthorService {

    private final FileUtil fileUtil;
    private final AuthorRepository authorRepository;

    @Autowired
    public AuthorServiceImpl(FileUtil fileUtil, AuthorRepository authorRepository) {
        this.fileUtil = fileUtil;
        this.authorRepository = authorRepository;
    }

    @Override
    public void seedAuthorsInDb() throws IOException {
        String [] lines = fileUtil.readFileContent(AUTHORS_FILE_PATH);
        for (String line: lines) {
            String [] split = line.split("\\s+");
            String firstName = split[0];
            String lastName = split[1];
            Author author = new Author(firstName, lastName);
            this.authorRepository.saveAndFlush(author);
        }
    }

    @Override
    public void findAllByFirstNameEndsWith(String ending) {
        this.authorRepository.findAllByFirstNameEndsWith(ending).forEach(author ->
                System.out.printf("%s %s%n", author.getFirstName(), author.getLastName()));
    }

    @Override
    public void printAllAuthorsByBooksCopies() {
        List<Author> authors = this.authorRepository.findAll();
        Map<String, Integer> authorCopies = new HashMap<>();
        authors.forEach(author -> {
            int sum = author.getBooks().stream().mapToInt(b -> b.getCopies()).sum();
            authorCopies.put((author.getFirstName() + " " + author.getLastName()), sum);
        });

        authorCopies.entrySet().stream().sorted((a,b) -> b.getValue() - a.getValue()).forEach(copy ->
                System.out.println(copy.getKey() + " - " + copy.getValue()));
    }

}
