package com.softuni.springintroex.domain.repositories;

import com.softuni.springintroex.domain.entities.AgeRestriction;
import com.softuni.springintroex.domain.entities.Book;
import com.softuni.springintroex.domain.entities.EditionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Set;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    Set<Book> findAllByAgeRestriction(AgeRestriction ageRestriction);

    Set<Book> findAllByEditionTypeEqualsAndCopiesLessThan(EditionType editionType, int num);
    Set<Book> findAllByPriceLessThanOrPriceGreaterThan(BigDecimal num1, BigDecimal num2);
    Set<Book> findAllByReleaseDateBeforeOrReleaseDateAfter(LocalDate year, LocalDate year2);
    Set<Book> findAllByReleaseDateBefore(LocalDate localDate);
    Set<Book> findAllByTitleContains(String pattern);
    Set<Book> findAllByAuthorLastNameStartsWith(String pattern);

    @Query("SELECT count(b) FROM Book b WHERE length(b.title) > :length")
    int getNumberOfBooksBasedOnLength(int length);

    Book findByTitle(String title);
    
    @Query("UPDATE Book b SET b.copies = b.copies + :copies WHERE b.releaseDate > :date")
    int updateCopies(int copies, LocalDate date);
}
