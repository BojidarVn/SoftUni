package com.softuni.springintroex.domain.entities;

public enum  AgeRestriction {
    MINOR, TEEN , ADULT;
}
