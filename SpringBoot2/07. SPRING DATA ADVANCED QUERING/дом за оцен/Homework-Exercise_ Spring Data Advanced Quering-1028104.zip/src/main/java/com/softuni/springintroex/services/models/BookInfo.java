package com.softuni.springintroex.services.models;

import com.softuni.springintroex.domain.entities.AgeRestriction;
import com.softuni.springintroex.domain.entities.EditionType;

import java.math.BigDecimal;

public class BookInfo {

    private String title;
    private BigDecimal price;
    private EditionType editionType;
    private AgeRestriction ageRestriction;

    public BookInfo(String title, BigDecimal price, EditionType editionType, AgeRestriction ageRestriction) {
        this.title = title;
        this.price = price;
        this.editionType = editionType;
        this.ageRestriction = ageRestriction;
    }

    public String getTitle() {
        return title;
    }

    public BigDecimal getPrice() {
        return price;
    }


    public EditionType getEditionType() {
        return editionType;
    }

    public AgeRestriction getAgeRestriction() {
        return ageRestriction;
    }
}
