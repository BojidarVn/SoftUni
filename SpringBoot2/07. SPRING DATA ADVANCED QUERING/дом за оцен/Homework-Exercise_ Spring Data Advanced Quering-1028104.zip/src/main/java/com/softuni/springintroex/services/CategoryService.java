package com.softuni.springintroex.services;

import java.io.IOException;

public interface CategoryService {

    void seedCategoriesInDB() throws IOException;
}
